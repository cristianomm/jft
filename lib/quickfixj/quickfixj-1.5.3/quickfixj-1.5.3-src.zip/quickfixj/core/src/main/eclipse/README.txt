The formatter.xml file can be imported into Eclipse and
implements the QuickFIX/J formatting guidelines.
